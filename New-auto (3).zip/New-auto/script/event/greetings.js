const moment = require('moment-timezone');

module.exports.config = {
    name: "greetings",
    version: "69",
    credits: "cliff",
    description: "autogreet"
};

let lastMessage = 0;

module.exports.handleEvent = async function ({ api, event }) {
    const arrayData = {
        "01:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 01:00 AM\n\nGood night! Rest well and dream big! 🌙" },
        "02:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 02:00 AM\n\nSo late! Please get some sleep. 😴" },
        "05:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 05:00 AM\n\nGood morning! 🌅 Fajr ka waqt ho gaya. Uth jao!" },
        "07:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 07:00 AM\n\nSubah Bakhair! 🌞 Nashta kar lo, din acha guzrey ga." },
        "10:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 10:00 AM\n\nGood morning! 🌻 Naye din ki nayi shuruat. Mehnat karo!" },
        "12:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 12:00 PM\n\nGood afternoon! 🍽️ Zuhr ka waqt hai, khana kha lo." },
        "02:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 02:00 PM\n\nDopahar ho gayi! ☕ Thodi chai pi lo aur fresh feel karo." },
        "03:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 03:00 PM\n\nGood afternoon! 🌳 Focused raho, manzil qareeb hai!" },
        "04:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 04:00 PM\n\nAssar ka waqt! 🌼 Thodi der rest karo phir wapas kaam pe." },
        "05:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 05:00 PM\n\nShaam ho gayi! 🌆 Maghrib ka waqt aa raha hai." },
        "06:30:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 06:30 PM\n\nMaghrib ki namaz ka waqt! 🕌 Raat ka khana bhi tayyar karo." },
        "07:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 07:00 PM\n\nGood evening! 🌠 Din bhar ki mehnat ka shukriya. Relax karo." },
        "09:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 09:00 PM\n\nIsha ka waqt! 🌕 Din ki achi batein yaad karo aur sukoon se raho." },
        "11:00:00 PM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 11:00 PM\n\nRaat zyadah ho gayi! 🌝 Jaldi so jao, kal phir naya din hai." },
        "12:00:00 AM": { message: "🔔𝗔𝘂𝘁𝗼𝗧𝗶𝗺𝗲:\n──────────────────\n⏰ time now: 12:00 AM\n\nAdhi Raat! 🌃 Agar jaag rahe ho to so jao. Good night!" }
    };

    const checkTimeAndSendMessage = async () => {
        const now = moment().tz('Asia/Karachi');
        const currentTime = now.format('hh:mm:ss A');

        const messageData = arrayData[currentTime];

        if (messageData) {
            const dateNow = Date.now();
            if (dateNow - lastMessage < 1 * 60 * 60 * 1000) {
                return;
            }
            lastMessage = dateNow;

            try {
                const threadList = await api.getThreadList(50, null, ["INBOX"]);
                threadList.forEach(async (thread) => {
                    const threadID = thread.threadID;
                    if (thread.isGroup && thread.name !== thread.threadID && thread.threadID !== event.threadID) {
                        api.sendMessage({ body: messageData.message }, threadID);
                    }
                });
            } catch (error) {
                console.error('[greetings]', error.message);
            }
        }

        const nextMinute = moment().add(1, 'minute').startOf('minute');
        const delay = nextMinute.diff(moment());
        setTimeout(checkTimeAndSendMessage, delay);
    };

    checkTimeAndSendMessage();
};
