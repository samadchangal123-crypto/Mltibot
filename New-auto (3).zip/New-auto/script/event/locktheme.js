const fs = require('fs');
const path = require('path');

const LOCKS_FILE = path.join(__dirname, '../../data/locks.json');
const restoring = new Set();

function readLocks() {
  try {
    if (!fs.existsSync(LOCKS_FILE)) return {};
    return JSON.parse(fs.readFileSync(LOCKS_FILE, 'utf8'));
  } catch { return {}; }
}

module.exports.config = {
  name: 'locktheme-event',
  version: '1.0.0',
  role: 0,
  description: 'Auto-restore group theme if locked',
  credits: 'System',
  hasEvent: true
};

module.exports.handleEvent = async function ({ api, event }) {
  if (event.logMessageType !== 'log:thread-color') return;

  const { threadID, author } = event;

  const botID = await api.getCurrentUserID();
  if (author == botID) return;
  if (restoring.has(threadID)) return;

  const locks = readLocks();
  const lock = locks[threadID]?.theme;
  if (!lock || !lock.active || !lock.value) return;

  restoring.add(threadID);
  setTimeout(() => restoring.delete(threadID), 8000);

  try {
    await api.changeThreadColor(lock.value, threadID);
    await api.sendMessage(
      `🔒 Theme has been restored!\n\nThis group's theme is locked by admin.`,
      threadID
    );
  } catch (err) {
    console.error('[locktheme-event] restore error:', err?.message || err);
  }
};
