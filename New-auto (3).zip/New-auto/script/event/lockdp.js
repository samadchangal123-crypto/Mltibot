const fs = require('fs');
const path = require('path');

const LOCKS_FILE = path.join(__dirname, '../../data/locks.json');
const restoring = new Set();

function readLocks() {
  try {
    if (!fs.existsSync(LOCKS_FILE)) return {};
    return JSON.parse(fs.readFileSync(LOCKS_FILE, 'utf8'));
  } catch { return {}; }
}

module.exports.config = {
  name: 'lockdp-event',
  version: '1.2.0',
  role: 0,
  description: 'Auto-restore group DP if locked',
  credits: 'System',
  hasEvent: true
};

module.exports.handleEvent = async function ({ api, event }) {
  if (event.type !== 'change_thread_image') return;

  const { threadID, author } = event;

  const botID = await api.getCurrentUserID();
  if (author == botID) return;
  if (restoring.has(threadID)) return;

  const locks = readLocks();
  const lock = locks[threadID]?.dp;
  if (!lock || !lock.active || !lock.localPath) return;
  if (!fs.existsSync(lock.localPath)) return;

  restoring.add(threadID);
  setTimeout(() => restoring.delete(threadID), 10000);

  try {
    await api.changeGroupImage(fs.createReadStream(lock.localPath), threadID);
    await api.sendMessage(
      `🔒 Group DP has been restored!\n\n🖼️ This group's photo is locked by admin.`,
      threadID
    );
  } catch (err) {
    console.error('[lockdp-event] restore error:', err?.message || err);
  }
};
