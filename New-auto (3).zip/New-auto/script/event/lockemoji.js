const fs = require('fs');
const path = require('path');

const LOCKS_FILE = path.join(__dirname, '../../data/locks.json');

function readLocks() {
  try {
    if (!fs.existsSync(LOCKS_FILE)) return {};
    return JSON.parse(fs.readFileSync(LOCKS_FILE, 'utf8'));
  } catch { return {}; }
}

module.exports.config = {
  name: 'lockemoji-event',
  version: '1.4.0',
  role: 0,
  description: 'Auto-restore group emoji if locked',
  credits: 'System',
  hasEvent: true
};

module.exports.handleEvent = async function ({ api, event }) {
  if (event.logMessageType !== 'log:thread-icon') return;

  const { threadID, author } = event;

  const botID = await api.getCurrentUserID();
  if (author == botID) return;

  const locks = readLocks();
  const lock = locks[threadID]?.emoji;
  if (!lock || !lock.active || !lock.value) return;

  try {
    await api.changeThreadEmoji(lock.value, threadID);
    await api.sendMessage(
      `🔒 Group emoji has been restored!\n\n${lock.value} Emoji locked by admin.`,
      threadID
    );
  } catch (err) {
    console.error('[lockemoji-event] restore error:', err?.message || err);
  }
};
